#include <stdint.h>
#include <math.h>

uint32_t intSqrt( uint32_t a ){
    return (uint32_t) sqrt( (double) a );
}